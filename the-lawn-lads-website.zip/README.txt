THE LAWN LADS — WEBSITE FILES
===============================

What's in this folder:
  index.html   The website itself (self-contained — all styling and
               scripting is built in, nothing else to install)
  before.jpg   Photo used in the "Before & after" section
  after.jpg    Photo used in the "Before & after" section

These three files ARE the whole website. To host it yourself:

1. BUY A DOMAIN
   e.g. thelawnlads.co.uk from Namecheap, IONOS, 123-reg, or Cloudflare
   Registrar — usually £8-12/year for a .co.uk.

2. UPLOAD THESE FILES TO A FREE STATIC HOST
   Any of these work well and have a free tier that's enough for this site:
     - Netlify        (netlify.com)   — drag-and-drop this folder in
     - Vercel         (vercel.com)
     - Cloudflare Pages (pages.cloudflare.com)
     - GitHub Pages   (pages.github.com) — needs a GitHub repo

   Keep all three files in the SAME folder when you upload — index.html
   refers to before.jpg and after.jpg by name, so they need to sit next
   to it, not in a subfolder.

3. POINT YOUR DOMAIN AT THE HOST
   Whichever host you pick will give you 1-2 DNS records to add at your
   domain registrar (usually copy-paste). This normally takes 10-15
   minutes to set up and a few hours to fully go live. Every host has a
   step-by-step guide for "connect a custom domain".

4. (OPTIONAL) SET UP A REAL EMAIL ADDRESS
   Once the domain is yours, hello@thelawnlads.co.uk becomes possible.
   Zoho Mail has a genuinely free plan for one custom-domain inbox;
   Google Workspace is the paid alternative (~£5/month).

That's it — there's no server to maintain and no backend to keep
running. To update the site later (new price, new photo, etc.), just
edit index.html and re-upload it to whichever host you chose.

NOTE ON THE BOOKING BUTTON
The "Book online" buttons link to your Cal.com page:
  https://cal.com/finley-glover-enio4n
That's hosted by Cal.com itself, so it keeps working regardless of
where you host this site — nothing to change there.

WhatsApp, call and email links point to 07912 613180 and
hello@thelawnlads.co.uk (the latter is a placeholder until you set up
a real inbox at your own domain — see step 4).
